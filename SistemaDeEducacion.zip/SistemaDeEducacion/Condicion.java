package Parciales.SistemaDeEducacion;

public abstract class Condicion {
    public abstract boolean cumple(Elemento e);
}
